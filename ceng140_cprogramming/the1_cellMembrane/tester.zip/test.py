from subprocess import call
import os
call(["gcc","the1.c","-o","compiled","-Wall","-pedantic","-ansi"])
score=0
total=100
success=call(["ls","compiled"])
if success==0:
	for i in range(1,total+1):
		log="Logs/"+str(i)+".log"
		logFILE=open(log,"w+");
		inp="In-Out/"+str(i)+".in"
		outp="In-Out/"+str(i)+".out"
		outFILE=open(outp,"r").readlines()[0];
		lel="./compiled < "+inp;
		try:
			handle=os.popen(lel);
			res=handle.readline();
			if res[-1]==" ":
				k=-1
			else:
				k=len(res)
			if res[:k]==outFILE:
				score+=1
			print "####Input "+str(i)+" :"+str(res[:k]==outFILE)
			logFILE.write(str(res[:k]==outFILE)+"\n"+"Your result: "+res[:k]+"\n"+"Expected result: "+outFILE+"\n");
		except Exception:
			print "####Input "+str(i)+" :ERROR"
	print "Score:"+str(score)+"/"+str(total);
	call(["rm","compiled"]);
else:
	print "##### There is a compilation error.I cannot make test sooorrry :((."
