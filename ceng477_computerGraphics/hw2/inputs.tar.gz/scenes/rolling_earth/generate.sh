#!/bin/bash

bash generate1.sh
bash generate2.sh
